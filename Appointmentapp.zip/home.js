

  function store(){
     var firstName= document.getElementById("fname");
     localStorage.setItem("fname", firstName.value);

     var lastName= document.getElementById("lname");
     localStorage.setItem("lname", lastName.value);

     var age= document.getElementById("age");
     localStorage.setItem("age", age.value);

     var appointmentdetails= document.getElementById("appointment_details");
     localStorage.setItem("appointment_details", appointmentdetails.value);

     var time= document.getElementById("time");
     localStorage.setItem("time", time.value);

     var date= document.getElementById("date");
     localStorage.setItem("date", date.value);

     var gender= document.getElementById("gender");
     localStorage.setItem("gender", gender.value);
    }
